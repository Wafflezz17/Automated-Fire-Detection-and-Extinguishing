#ifndef __SERVO_H
#define __SERVO_H

#include "main.h"

// --- USER MUST DEFINE THIS ---
// CRITICAL: Ensure this handle name matches the one defined in your main.c (e.g., if CubeMX named it 'htim1')
extern TIM_HandleTypeDef htim1; // Assuming your timer handle is 'htim1'
#define SERVO_TIMER_HANDLE &htim1
#define SERVO_PWM_CHANNEL  TIM_CHANNEL_1

// CRITICAL: Period calculation based on 1us tick frequency (Bus Clock / 80)
// 20ms period = 20,000 ticks.
#define PWM_PERIOD_MAX     20000
// Pulse width minimum (1ms) and maximum (2ms) in ticks
#define PULSE_MIN_TICKS    1000  // 1.0 ms
#define PULSE_RANGE_TICKS  1000  // 2.0 ms - 1.0 ms
// --- END USER DEFINITION ---

/**
 * @brief Initialize the Servo PWM signal. (Starts the PWM timer)
 */
void Servo_Init(void);

/**
 * @brief Sets the servo angle from 0.0f to 180.0f.
 * @param angle The desired angle.
 */
void Servo_SetAngle(float angle);

#endif // __SERVO_H
