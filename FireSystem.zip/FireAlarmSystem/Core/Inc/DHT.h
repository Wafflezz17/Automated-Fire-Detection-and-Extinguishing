#ifndef __DHT_H
#define __DHT_H
#include "stm32l4xx_hal.h"
#define DHT11_PORT GPIOB
#define DHT11_PIN GPIO_PIN_0
uint8_t DHT_ReadData(float *humidity, float *temperature);
#endif
