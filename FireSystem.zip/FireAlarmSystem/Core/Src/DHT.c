#include "DHT.h"
#include "cmsis_os.h"
#include "stdio.h"
extern TIM_HandleTypeDef htim2; // use TIM2 for microsecond timing
static void delay_us(uint16_t us) {
__HAL_TIM_SET_COUNTER(&htim2, 0);
while (__HAL_TIM_GET_COUNTER(&htim2) < us);
}
// Send start signal
static void DHT_Start(void) {
GPIO_InitTypeDef GPIO_InitStruct = {0};
GPIO_InitStruct.Pin = DHT11_PIN;
GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_RESET);
osDelay(18); // pull low for 18 ms
HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, GPIO_PIN_SET);
delay_us(30);
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_NOPULL;
HAL_GPIO_Init(DHT11_PORT, &GPIO_InitStruct);
}
// Check sensor response
static uint8_t DHT_CheckResponse(void) {
delay_us(40);
if (!HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)) {
delay_us(80);
if (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)) {
while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN));
return 1;
}
}
return 0;
}
// Read one byte
static uint8_t DHT_ReadByte(void) {
uint8_t i, byte = 0;
for (i = 0; i < 8; i++) {
while (!HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN));
delay_us(35);
if (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))
byte |= (1 << (7 - i));
while (HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN));
}
return byte;
}
// Read full data frame
uint8_t DHT_ReadData(float *humidity, float *temperature) {
uint8_t Rh_byte1, Rh_byte2, Temp_byte1, Temp_byte2, sum;
uint16_t Rh, Temp;
DHT_Start();
if (DHT_CheckResponse()) {
	Rh_byte1 = DHT_ReadByte();
	Rh_byte2 = DHT_ReadByte();
	Temp_byte1 = DHT_ReadByte();
	Temp_byte2 = DHT_ReadByte();
	sum = DHT_ReadByte();
	if (sum == (Rh_byte1 + Rh_byte2 + Temp_byte1 + Temp_byte2)) {
		*humidity = Rh_byte1;
		*temperature = Temp_byte1;
		return 0; // success
}
}
	return 1; // error
}
