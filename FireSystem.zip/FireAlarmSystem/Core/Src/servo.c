#include "servo.h"
#include <math.h>

void Servo_Init(void) {
    // CRITICAL: Start PWM signal generation on the defined channel
    HAL_TIM_PWM_Start(SERVO_TIMER_HANDLE, SERVO_PWM_CHANNEL);
}


void Servo_SetAngle(float angle) {
    // Clamp the angle between 0 and 180 degrees
//    if (angle < 0.0f) angle = 0.0f;
//    if (angle > 180.0f) angle = 180.0f;

    // Calculate the Compare Value (CCR) based on the 1ms to 2ms pulse range.
    // CCR = MIN_PULSE_TICKS + (Angle / 180) * PULSE_RANGE_TICKS
    uint32_t compare_value = PULSE_MIN_TICKS +
                             (uint32_t)roundf(angle / 180.0f * PULSE_RANGE_TICKS);

    // Write the new Compare Value to the Timer Capture/Compare Register
    __HAL_TIM_SET_COMPARE(SERVO_TIMER_HANDLE, SERVO_PWM_CHANNEL, compare_value);
}
