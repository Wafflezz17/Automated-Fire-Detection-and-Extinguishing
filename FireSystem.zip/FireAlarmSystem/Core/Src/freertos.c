/* USER CODE BEGIN Header */
///**
//  ******************************************************************************
//  * @file    : freertos.c
//  * @brief   : FreeRTOS tasks for Automated Fire Detection System
//  * Date    : November 2025
//  ******************************************************************************
//  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "servo.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
extern UART_HandleTypeDef huart2;
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim1;
volatile bool flameDetected = false;
volatile bool smokeDetected = false;
uint32_t smokeValue = 0;
uint32_t smokeThreshold = 2000; // Adjust this threshold as needed
// Task handles
osThreadId_t flameHandle;
osThreadId_t buzzerHandle;
osThreadId_t smokeHandle;
osThreadId_t relayHandle;
osThreadId_t servoWaterHandle;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
//
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
const osThreadAttr_t flame_attributes = {
	.name = "FlameTask",
	.priority = (osPriority_t) osPriorityNormal,
	.stack_size = 128 * 4
};

const osThreadAttr_t buzzer_attributes = {
	.name = "BuzzerTask",
	.priority = (osPriority_t) osPriorityBelowNormal,
	.stack_size = 128 * 4
};

const osThreadAttr_t smoke_attributes = {
	.name = "SmokeTask",
	.priority = (osPriority_t) osPriorityNormal,
	.stack_size = 128 * 4
};

const osThreadAttr_t relay_attributes = {
	.name = "RelayTask",
	.priority = (osPriority_t) osPriorityNormal,
	.stack_size = 128 * 4
};
//servo for water
const osThreadAttr_t servoW_attributes = {
	.name = "ServoWTask",
	.priority = (osPriority_t) osPriorityHigh,
	.stack_size = 128 * 4
};
//
/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for buzzerSem */
osSemaphoreId_t buzzerSemHandle;
const osSemaphoreAttr_t buzzerSem_attributes = {
  .name = "buzzerSem"
};
/* Definitions for relaySem */
osSemaphoreId_t relaySemHandle;
const osSemaphoreAttr_t relaySem_attributes = {
  .name = "relaySem"
};
/* Definitions for servoSem */
osSemaphoreId_t servoSemHandle;
const osSemaphoreAttr_t servoSem_attributes = {
  .name = "servoSem"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void StartBuzzerTask (void *argument) {
	for(;;) {
		//this task will be blocked until it acquires a sem once acquired it will perform its action withing a while n once no more triggerrs it goes back to block
		//task is blocked until it aqquires a semaphore from either sensors
        osSemaphoreAcquire(buzzerSemHandle, osWaitForever);

        // Keep relay ON while sensors detect any fire flame or smoke
        while (flameDetected || smokeDetected) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET);
            osDelay(200);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
            osDelay(200);
        }

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); //buzzer offf
	}
	osDelay(100);
}//end buzz

void StartRelayTask (void *argument) {
	for(;;) {
		//task is blocked until it aqquires a semaphore from either sensors
        osSemaphoreAcquire(relaySemHandle, osWaitForever);

        // Keep relay ON while sensors detect any fire flame or smoke
        while (flameDetected || smokeDetected) {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET); //relay on --> water pump on
            osDelay(100); //small delay
        }

        // Turn relay OFF when both sensor dont show any readings anymore through the bool variables
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET); //relay off --> pump off
	}
	osDelay(100);
}//end relay

void StartFlameTask (void *argument) {
	char msg[64];
	for(;;){
		if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5) == GPIO_PIN_SET) { //detected flame
			flameDetected = true;
			osSemaphoreRelease(buzzerSemHandle); //signal a semaphore for buzzer to buzz
			osSemaphoreRelease(relaySemHandle); //signal a semaphore for the relay to turn on pump
			osSemaphoreRelease(servoSemHandle); //signal to servo to keep moving
			sprintf(msg, "Flame DETECTED!!!!!\r\n");
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
		} else {
			flameDetected = false;
			sprintf(msg, "no flame :)\r\n");
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
		}
	    osDelay(500);
	}
}//end flame

void StartSmokeTask (void *argument) {
	for (;;) {
		// Start ADC conversion
		HAL_ADC_Start(&hadc1);
		// Poll for conversion completion
		HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
		// Get the ADC value
		smokeValue = HAL_ADC_GetValue(&hadc1);
		char msg[64];
		// Simple threshold-based smoke detection
		if (smokeValue > smokeThreshold) {
			//semaphoresss releases on event (smoke present)
			osSemaphoreRelease(buzzerSemHandle);
			osSemaphoreRelease(relaySemHandle);
			osSemaphoreRelease(servoSemHandle);
			smokeDetected = true;
			sprintf(msg, "Smokeee Detected!!!!\r\n");
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
		} else {
			smokeDetected = false;
			sprintf(msg, "NO SMOKEEE!!!!\r\n");
			HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
		}
		osDelay(500); // delay 0.5s
	}
}//end smoke

void StartServoWaterTask(void *argument) {
	//task is blocked until it aqquires a semaphore from either sensors
    for (;;) {
        osSemaphoreAcquire(servoSemHandle, osWaitForever);
        float angle = 70; //set an angle
        bool direction = true; //set a direction tracker
        //the servo will only sweep if smoke or flame detected else no
        while (flameDetected || smokeDetected) {
            Servo_SetAngle(angle);
            //sweeping motions
            if (direction) //we wana keep moving
                angle += 10.0f;
            else //we reached max direction now we want to change the direction
                angle -= 10.0f;
            //these conditions will limit the sweeping angles of the servo so we dont spray water beyond a certian area
            if (angle >= 260.0f) direction = false;
            if (angle <= 70.0f)   direction = true;
            osDelay(20);   // for smooth operation
        }
    }
}



/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
	//semaphores shall be initialized b4 the tasks so the tasks can acquire/release them !
	buzzerSemHandle = osSemaphoreNew(1, 0, &buzzerSem_attributes);
	relaySemHandle = osSemaphoreNew(1, 0, &relaySem_attributes);
	servoSemHandle = osSemaphoreNew(1, 0, &servoSem_attributes);

	flameHandle = osThreadNew(StartFlameTask, NULL, &flame_attributes);
	buzzerHandle = osThreadNew(StartBuzzerTask, NULL, &buzzer_attributes);
	smokeHandle = osThreadNew(StartSmokeTask, NULL, &smoke_attributes);
	relayHandle = osThreadNew(StartRelayTask, NULL, &relay_attributes);
	servoWaterHandle = osThreadNew(StartServoWaterTask, NULL, &servoW_attributes);
//
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
//  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of buzzerSem */
//  buzzerSemHandle = osSemaphoreNew(1, 1, &buzzerSem_attributes);
//
//  /* creation of relaySem */
//  relaySemHandle = osSemaphoreNew(1, 1, &relaySem_attributes);
//
//  /* creation of servoSem */
//  servoSemHandle = osSemaphoreNew(1, 1, &servoSem_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
//  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
//  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
//  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
//  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
//  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
///**
//  * @brief  Function implementing the defaultTask thread.
//  * @param  argument: Not used
//  * @retval None
//  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

